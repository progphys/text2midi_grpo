#!/usr/bin/env bash
set -euo pipefail
latexmk -pdf -interaction=nonstopmode -halt-on-error coursework.tex
